//
//  LocationManagerLibrary.h
//  LocationManagerLibrary
//
//  Created by umut on 26.02.2019.
//  Copyright © 2019 Koçsistem. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LocationManagerLibrary.
FOUNDATION_EXPORT double LocationManagerLibraryVersionNumber;

//! Project version string for LocationManagerLibrary.
FOUNDATION_EXPORT const unsigned char LocationManagerLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LocationManagerLibrary/PublicHeader.h>


